import React from 'react'
import AppointmentForm from './Components/AppointmentForm';

const App = () => {
  return (
    <>
      <AppointmentForm/>  
    </>
  )
}

export default App;